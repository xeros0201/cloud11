module.exports = [
    { name: "Home" , link: "/"},
    { name: "Product" , link: "/product"},
    { name: "Order" , link: "/order"},
    { name: "Payment" , link: "/payment"},
    { name: "Report" , link: "/report"},
    { name: "Login" , link: "/login"},
    { name: "create User" , link: "/user/create"},
    { name: "QR code - link" , link: "/qr"},
];